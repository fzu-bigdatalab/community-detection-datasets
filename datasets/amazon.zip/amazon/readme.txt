description:
Amazon product network
Nodes	334863
Edges	925872

source: http://snap.stanford.edu/data/com-Amazon.html
citation: J. Yang and J. Leskovec. Defining and Evaluating Network Communities based on Ground-truth. ICDM, 2012.
