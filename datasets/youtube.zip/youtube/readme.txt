description:
Youtube online social network
Nodes	1134890
Edges	2987624

source: http://snap.stanford.edu/data/com-Youtube.html
citation: J. Yang and J. Leskovec. Defining and Evaluating Network Communities based on Ground-truth. ICDM, 2012.